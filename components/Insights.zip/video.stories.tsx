import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";
import Video from "./video";
// import imageFile from '../public/videoPics.jpg' 

export default {
  title: "Video",
  component: Video,
} as ComponentMeta<typeof Video>;

export const Template: ComponentStory<typeof Video> = (args) => (
  <Video {...args} />
);

// const image = {
//     src:imageFile,
//     alt:'myImage'
// }

// export const WithAnImage = () => <img src={image.src} alt={image.alt} />;
